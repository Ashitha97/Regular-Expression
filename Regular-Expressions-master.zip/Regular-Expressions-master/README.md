# Regular-Expressions
Regular expression is a sequence of characters mainly used to find and replace pattern in a string or in file.
Regular expression can help in complex text manipulation by using fairly simple expressions.
